# MAX30100 [![Build Status](https://travis-ci.org/kontakt/MAX30100.svg?branch=master)](https://travis-ci.org/kontakt/MAX30100)
A library for the Maxim MAX30100 pulse oximetry chip

This library is designed to interface with the MAXIM MAX30100 Heart Rate and SpO2 sensor chip.
The current status of the library allows reading of the IR values for Heart Rate determination and the manipulatuion of any register.
